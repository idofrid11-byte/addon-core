# StreamVerse - Stremio Alternative Media Hub Engine

StreamVerse is an open-source web-based media streaming application built around the native **Stremio Addon Protocol Specification (v3)**.

## Features
- **Native Stremio Addon Engine**: Consumes manifest endpoints, catalogs, metadata, and stream resolvers.
- **CORS Proxy Integration**: Dynamic fallback proxies for fetching remote manifests without server limitations.
- **Dynamic Player**: HTML5 MP4/HLS playback, YouTube embed fallback, and Torrent magnet link protocol handler.
- **Library & Watchlist**: Persistent state saved via browser `localStorage`.
- **Modern UI**: Dark-mode glassmorphism interface powered by Tailwind CSS.

## Getting Started
```bash
# Docker Compose execution
docker-compose up -d

# Direct browser launch
open index.html
```
