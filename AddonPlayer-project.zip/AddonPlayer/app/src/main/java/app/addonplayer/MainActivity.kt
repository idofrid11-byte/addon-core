package app.addonplayer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import app.addonplayer.core.MetaPreview
import coil.compose.AsyncImage

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppRoot() }
    }
}

@Composable
fun AppRoot(vm: AppViewModel = viewModel()) {
    BackHandler(enabled = vm.screen != Screen.Home) { vm.back() }
    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface(Modifier.fillMaxSize()) {
            when (vm.screen) {
                Screen.Home -> HomeScreen(vm)
                Screen.Addons -> AddonsScreen(vm)
                Screen.Detail -> DetailScreen(vm)
                Screen.Player -> PlayerScreen(vm)
            }
        }
    }
}

@Composable
fun Poster(item: MetaPreview, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(8.dp)
    Column(
        Modifier
            .width(140.dp)
            .onFocusChanged { focused = it.isFocused }
            .border(if (focused) 3.dp else 0.dp, MaterialTheme.colorScheme.primary, shape)
            .clip(shape)
            .clickable(onClick = onClick)
    ) {
        AsyncImage(
            model = item.poster,
            contentDescription = item.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(2f / 3f)
                .background(MaterialTheme.colorScheme.surfaceVariant),
        )
        Text(item.name, maxLines = 2, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(6.dp), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun HomeScreen(vm: AppViewModel) {
    Column(Modifier.fillMaxSize().padding(24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("AddonPlayer", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
            Button(onClick = { vm.refresh() }) { Text("Refresh") }
            Spacer(Modifier.width(8.dp))
            Button(onClick = { vm.screen = Screen.Addons }) { Text("Addons") }
        }
        Spacer(Modifier.height(16.dp))
        when {
            vm.loading -> CircularProgressIndicator()
            vm.rows.isEmpty() -> Text("No catalogs yet. Open Addons and install one by pasting its manifest URL.")
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(20.dp)) {
                items(vm.rows) { row ->
                    Text(row.first, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(row.second) { m -> Poster(m) { vm.open(m) } }
                    }
                }
            }
        }
    }
}

@Composable
fun AddonsScreen(vm: AppViewModel) {
    var url by remember { mutableStateOf("") }
    val addons by vm.addons.collectAsState()
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Addons", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
            Button(onClick = { vm.back() }) { Text("Back") }
        }
        OutlinedTextField(
            value = url, onValueChange = { url = it }, singleLine = true,
            label = { Text("Addon manifest URL") }, modifier = Modifier.fillMaxWidth(),
        )
        Button(onClick = { vm.install(url); url = "" }, enabled = url.isNotBlank()) { Text("Install") }
        vm.message?.let { Text(it, color = MaterialTheme.colorScheme.secondary) }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(addons) { a ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(a.manifest.name, style = MaterialTheme.typography.titleMedium)
                        Text(a.manifest.description ?: a.url, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                    }
                    Button(onClick = { vm.remove(a) }) { Text("Remove") }
                }
            }
        }
    }
}

@Composable
fun DetailScreen(vm: AppViewModel) {
    val ctx = LocalContext.current
    val d = vm.detail ?: return
    LazyColumn(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.Top) {
                AsyncImage(
                    model = d.poster, contentDescription = d.name, contentScale = ContentScale.Crop,
                    modifier = Modifier.width(120.dp).aspectRatio(2f / 3f).clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                )
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(d.name, style = MaterialTheme.typography.headlineSmall)
                    d.releaseInfo?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                    Spacer(Modifier.height(8.dp))
                    Text(d.description ?: "", style = MaterialTheme.typography.bodyMedium)
                }
                Button(onClick = { vm.back() }) { Text("Back") }
            }
        }
        if (d.type == "series" && d.videos.isNotEmpty()) {
            item { Text("Episodes", style = MaterialTheme.typography.titleMedium) }
            items(d.videos) { v ->
                val label = buildString {
                    if (v.season != null && v.episode != null) append("S${v.season}E${v.episode} · ")
                    append(v.title ?: v.id)
                }
                Button(onClick = { vm.loadStreams(d.type, v.id) }, modifier = Modifier.fillMaxWidth()) { Text(label) }
            }
        }
        item { Text("Streams", style = MaterialTheme.typography.titleMedium) }
        if (vm.streamsLoading) item { CircularProgressIndicator() }
        else if (vm.streams.isEmpty()) item { Text("No streams available from your installed addons.") }
        items(vm.streams) { (addon, s) ->
            Button(onClick = { vm.play(ctx, s) }, modifier = Modifier.fillMaxWidth()) {
                Text("${addon.manifest.name} · ${s.name ?: s.title ?: "Stream"}", maxLines = 2)
            }
        }
    }
}

@Composable
fun PlayerScreen(vm: AppViewModel) {
    val stream = vm.playing ?: return
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(stream) {
        val subs = stream.subtitles.map {
            MediaItem.SubtitleConfiguration.Builder(android.net.Uri.parse(it.url))
                .setMimeType(MimeTypes.APPLICATION_SUBRIP).setLanguage(it.lang).build()
        }
        player.setMediaItem(
            MediaItem.Builder().setUri(stream.url).setSubtitleConfigurations(subs).build()
        )
        player.prepare()
        player.playWhenReady = true
        onDispose { player.release() }
    }
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { c ->
            PlayerView(c).apply {
                this.player = player
                useController = true
                isFocusable = true
                requestFocus()
            }
        },
    )
}
