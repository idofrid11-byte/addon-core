package app.addonplayer

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import app.addonplayer.core.AddonStore
import kotlinx.coroutines.flow.first

private val Context.addonDataStore by preferencesDataStore("addons")

class DataStoreAddonStore(private val ctx: Context) : AddonStore {
    private val key = stringSetPreferencesKey("urls")

    override suspend fun urls(): List<String> =
        ctx.addonDataStore.data.first()[key]?.toList() ?: emptyList()

    override suspend fun add(url: String) {
        ctx.addonDataStore.edit { it[key] = (it[key] ?: emptySet()) + url }
    }

    override suspend fun remove(url: String) {
        ctx.addonDataStore.edit { it[key] = (it[key] ?: emptySet()) - url }
    }
}
