/*
 * AddonCore.kt: core of an addon-based media app (phone + Android TV)
 *
 * build.gradle.kts dependencies:
 *   implementation("io.ktor:ktor-client-okhttp:2.3.12")
 *   implementation("io.ktor:ktor-client-content-negotiation:2.3.12")
 *   implementation("io.ktor:ktor-serialization-kotlinx-json:2.3.12")
 *   implementation("androidx.media3:media3-exoplayer:1.4.1")
 *   implementation("androidx.media3:media3-exoplayer-hls:1.4.1")
 *   implementation("androidx.media3:media3-ui:1.4.1")
 *   implementation("androidx.tv:tv-material:1.0.0")        // TV UI (Compose for TV)
 *   implementation("androidx.compose.material3:material3") // phone UI
 *   implementation("androidx.datastore:datastore-preferences:1.1.1")
 *   implementation("io.coil-kt:coil-compose:2.7.0")
 *
 * AndroidManifest.xml (so it installs on both):
 *   <uses-feature android:name="android.software.leanback" android:required="false"/>
 *   <uses-feature android:name="android.hardware.touchscreen" android:required="false"/>
 *   Activity intent-filter: LAUNCHER + LEANBACK_LAUNCHER
 *
 * Addon protocol (Stremio-style):
 *   GET {base}/manifest.json
 *   GET {base}/catalog/{type}/{id}.json
 *   GET {base}/meta/{type}/{id}.json
 *   GET {base}/stream/{type}/{id}.json
 */

package app.addonplayer.core

import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.okhttp.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

// ---------- Models ----------

@Serializable
data class Manifest(
    val id: String,
    val name: String,
    val version: String = "0",
    val description: String? = null,
    val logo: String? = null,
    val resources: List<String> = emptyList(),   // "catalog", "meta", "stream"
    val types: List<String> = emptyList(),       // "movie", "series", "tv", ...
    val catalogs: List<CatalogDef> = emptyList(),
    val idPrefixes: List<String>? = null,
)

@Serializable
data class CatalogDef(val type: String, val id: String, val name: String? = null)

@Serializable
data class CatalogResponse(val metas: List<MetaPreview> = emptyList())

@Serializable
data class MetaPreview(
    val id: String,
    val type: String,
    val name: String,
    val poster: String? = null,
    val description: String? = null,
)

@Serializable
data class MetaResponse(val meta: MetaDetail)

@Serializable
data class MetaDetail(
    val id: String,
    val type: String,
    val name: String,
    val poster: String? = null,
    val background: String? = null,
    val description: String? = null,
    val releaseInfo: String? = null,
    val videos: List<Video> = emptyList(),       // episodes for series
)

@Serializable
data class Video(val id: String, val title: String? = null, val season: Int? = null, val episode: Int? = null)

@Serializable
data class StreamResponse(val streams: List<Stream> = emptyList())

@Serializable
data class Stream(
    val url: String? = null,         // direct http(s) / HLS / DASH: playable with Media3
    val ytId: String? = null,        // YouTube id: open via YouTube app/intent
    val externalUrl: String? = null, // open in browser/other app
    val name: String? = null,
    val title: String? = null,
    val subtitles: List<Subtitle> = emptyList(),
)

@Serializable
data class Subtitle(val url: String, val lang: String)

// ---------- Addon client ----------

class AddonClient(private val http: HttpClient = defaultClient()) {

    private fun String.base() = removeSuffix("/manifest.json").trimEnd('/')

    suspend fun manifest(addonUrl: String): Manifest =
        http.get("${addonUrl.base()}/manifest.json").body()

    suspend fun catalog(addonUrl: String, type: String, id: String): List<MetaPreview> =
        http.get("${addonUrl.base()}/catalog/$type/$id.json").body<CatalogResponse>().metas

    suspend fun meta(addonUrl: String, type: String, id: String): MetaDetail =
        http.get("${addonUrl.base()}/meta/$type/$id.json").body<MetaResponse>().meta

    suspend fun streams(addonUrl: String, type: String, id: String): List<Stream> =
        http.get("${addonUrl.base()}/stream/$type/$id.json").body<StreamResponse>().streams

    companion object {
        fun defaultClient() = HttpClient(OkHttp) {
            install(ContentNegotiation) {
                json(Json { ignoreUnknownKeys = true; isLenient = true; coerceInputValues = true })
            }
            engine { config { callTimeout(java.time.Duration.ofSeconds(15)) } }
        }
    }
}

// ---------- Repository: fans out across all installed addons ----------

data class InstalledAddon(val url: String, val manifest: Manifest)

class AddonRepository(
    private val client: AddonClient,
    private val store: AddonStore,   // persists addon URLs (DataStore)
) {
    val addons: StateFlow<List<InstalledAddon>> get() = _addons
    private val _addons = MutableStateFlow<List<InstalledAddon>>(emptyList())

    suspend fun load() {
        _addons.value = store.urls().mapNotNull { url ->
            runCatching { InstalledAddon(url, client.manifest(url)) }.getOrNull()
        }
    }

    suspend fun install(url: String): Result<InstalledAddon> = runCatching {
        val addon = InstalledAddon(url, client.manifest(url))
        store.add(url)
        _addons.value = _addons.value.filterNot { it.manifest.id == addon.manifest.id } + addon
        addon
    }

    suspend fun remove(addon: InstalledAddon) {
        store.remove(addon.url)
        _addons.value = _addons.value - addon
    }

    /** Home screen rows: one row per catalog from every addon that serves "catalog". */
    suspend fun homeRows(): List<Pair<String, List<MetaPreview>>> = coroutineScope {
        _addons.value
            .filter { "catalog" in it.manifest.resources || it.manifest.catalogs.isNotEmpty() }
            .flatMap { a -> a.manifest.catalogs.map { a to it } }
            .map { (addon, cat) ->
                async {
                    runCatching {
                        val title = "${cat.name ?: cat.id} · ${addon.manifest.name}"
                        title to client.catalog(addon.url, cat.type, cat.id)
                    }.getOrNull()
                }
            }.awaitAll().filterNotNull().filter { it.second.isNotEmpty() }
    }

    /** Ask every stream-capable addon (respecting idPrefixes) and merge results. */
    suspend fun streamsFor(type: String, id: String): List<Pair<InstalledAddon, Stream>> = coroutineScope {
        _addons.value
            .filter { a ->
                "stream" in a.manifest.resources &&
                    (a.manifest.types.isEmpty() || type in a.manifest.types) &&
                    (a.manifest.idPrefixes == null || a.manifest.idPrefixes.any { id.startsWith(it) })
            }
            .map { a -> async { runCatching { client.streams(a.url, type, id).map { a to it } }.getOrDefault(emptyList()) } }
            .awaitAll().flatten()
    }

    suspend fun meta(type: String, id: String): MetaDetail? = coroutineScope {
        _addons.value
            .filter { "meta" in it.manifest.resources }
            .map { a -> async { runCatching { client.meta(a.url, type, id) }.getOrNull() } }
            .awaitAll().firstNotNullOfOrNull { it }
    }
}

interface AddonStore {
    suspend fun urls(): List<String>
    suspend fun add(url: String)
    suspend fun remove(url: String)
}

// ---------- Playback (Media3) ----------
/*
 * fun play(context: Context, stream: Stream, player: ExoPlayer) {
 *     when {
 *         stream.url != null -> {
 *             val subs = stream.subtitles.map {
 *                 MediaItem.SubtitleConfiguration.Builder(Uri.parse(it.url))
 *                     .setMimeType(MimeTypes.APPLICATION_SUBRIP)
 *                     .setLanguage(it.lang).build()
 *             }
 *             player.setMediaItem(MediaItem.Builder().setUri(stream.url).setSubtitleConfigurations(subs).build())
 *             player.prepare(); player.play()
 *         }
 *         stream.ytId != null -> context.startActivity(
 *             Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=${stream.ytId}")))
 *         stream.externalUrl != null -> context.startActivity(
 *             Intent(Intent.ACTION_VIEW, Uri.parse(stream.externalUrl)))
 *     }
 * }
 */

// ---------- UI notes ----------
/*
 * Phone:  Material3 Scaffold + NavigationBar (Home / Search / Addons / Settings),
 *         LazyColumn of LazyRows for homeRows(), detail screen with episode list,
 *         stream picker bottom sheet.
 *
 * TV:     androidx.tv.material3 (ImmersiveList / Carousel / Card), D-pad focus via
 *         Modifier.focusable() and FocusRequester, NavigationDrawer on the left.
 *         Detect at runtime:
 *           val isTv = context.packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
 *         and pick the TV or phone root composable. Both share AddonRepository + ViewModels.
 *
 * Addons screen: text field to paste a manifest URL -> repository.install(url).
 *         On TV, entering URLs by remote is painful, so offer a QR/phone-pairing flow:
 *         run a tiny local HTTP server (NanoHTTPD) on the TV, show its LAN address,
 *         and let the user paste the addon URL from a phone browser.
 */
