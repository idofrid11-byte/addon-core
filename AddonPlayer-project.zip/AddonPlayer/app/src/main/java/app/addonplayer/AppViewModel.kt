package app.addonplayer

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.addonplayer.core.*
import kotlinx.coroutines.launch

enum class Screen { Home, Addons, Detail, Player }

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = AddonRepository(AddonClient(), DataStoreAddonStore(app))

    val addons get() = repo.addons

    var screen by mutableStateOf(Screen.Home)
    var rows by mutableStateOf<List<Pair<String, List<MetaPreview>>>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var message by mutableStateOf<String?>(null)
    var detail by mutableStateOf<MetaDetail?>(null); private set
    var streams by mutableStateOf<List<Pair<InstalledAddon, Stream>>>(emptyList()); private set
    var streamsLoading by mutableStateOf(false); private set
    var playing by mutableStateOf<Stream?>(null); private set

    init {
        viewModelScope.launch { repo.load(); refresh() }
    }

    fun refresh() {
        viewModelScope.launch {
            loading = true
            rows = runCatching { repo.homeRows() }.getOrDefault(emptyList())
            loading = false
        }
    }

    fun install(url: String) {
        viewModelScope.launch {
            message = "Installing…"
            repo.install(url.trim()).fold(
                onSuccess = { message = "Installed ${it.manifest.name}"; refresh() },
                onFailure = { message = "Failed: ${it.message}" },
            )
        }
    }

    fun remove(addon: InstalledAddon) {
        viewModelScope.launch { repo.remove(addon); refresh() }
    }

    fun open(item: MetaPreview) {
        detail = MetaDetail(item.id, item.type, item.name, item.poster, null, item.description)
        streams = emptyList()
        screen = Screen.Detail
        viewModelScope.launch {
            repo.meta(item.type, item.id)?.let { detail = it }
            if (item.type != "series") loadStreams(item.type, item.id)
        }
    }

    fun loadStreams(type: String, id: String) {
        viewModelScope.launch {
            streamsLoading = true
            streams = runCatching { repo.streamsFor(type, id) }.getOrDefault(emptyList())
            streamsLoading = false
        }
    }

    fun play(context: Context, stream: Stream) {
        when {
            stream.url != null -> { playing = stream; screen = Screen.Player }
            stream.ytId != null -> openExternal(context, "https://www.youtube.com/watch?v=${stream.ytId}")
            stream.externalUrl != null -> openExternal(context, stream.externalUrl)
        }
    }

    private fun openExternal(context: Context, url: String) {
        runCatching {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    fun back() {
        screen = when (screen) {
            Screen.Player -> Screen.Detail
            else -> Screen.Home
        }
    }
}
